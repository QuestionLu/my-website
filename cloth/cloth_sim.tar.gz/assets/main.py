import pygame, math
import asyncio  # 新增：匯入非同步模組

async def main():  # 新增：將主程式包在 async 函式中
    pygame.init()
    # 修改：網頁版建議給定明確解析度，避免全螢幕報錯
    s = pygame.display.set_mode((1280, 720))
    W, H, clock = s.get_width(), s.get_height(), pygame.time.Clock()
    
    # 物理初始化 (根據 1280 寬度稍微調整了 X 軸的起始位置，讓布料置中)
    cloth_colors = [(0, 255, 150), (255, 100, 100), (100, 150, 255), (255, 200, 50), (200, 100, 255), (255, 255, 255)]
    color_idx = 0
    
    def init_cloth():
        start_x = (W - 49 * 20) / 2
        start_y = 50  # 距離上方留一點空白
        p_arr = [[x*20+start_x, y*20+start_y, x*20+start_x, y*20+start_y, y==0] for y in range(30) for x in range(50)]
        s_arr = [[i, i+1, 1] for i in range(len(p_arr)) if (i+1)%50] + [[i, i+50, 1] for i in range(len(p_arr)-50)]
        return p_arr, s_arr
        
    P, S = init_cloth()
    
    while True:
        # 修改：將原本的一行 exit 寫法拆開，這在網頁版比較穩定
        for e in pygame.event.get():
            if e.type == pygame.QUIT:
                return
            if e.type == pygame.KEYDOWN and e.key == pygame.K_ESCAPE:
                return
            if e.type == pygame.MOUSEBUTTONDOWN and e.button == 1:
                mx, my = e.pos
                # 檢查重置按鈕 (右上方，圓心 W-50, 50，半徑 20)
                if math.hypot(W - 50 - mx, 50 - my) < 20:
                    P, S = init_cloth()
                # 檢查顏色按鈕 (右上方，圓心 W-110, 50，半徑 20)
                elif math.hypot(W - 110 - mx, 50 - my) < 20:
                    color_idx = (color_idx + 1) % len(cloth_colors)
                
        s.fill((0, 5, 10))
        mx, my = pygame.mouse.get_pos()
        md = pygame.mouse.get_pressed()
        
        is_hovering_ui = math.hypot(W - 50 - mx, 50 - my) < 20 or math.hypot(W - 110 - mx, 50 - my) < 20
        
        for p in P:
            if not p[4]:
                if md[0] and not is_hovering_ui and math.hypot(p[0]-mx, p[1]-my) < 30: p[0], p[1] = mx, my
                vx, vy = max(-20, min(20, (p[0]-p[2])*0.99)), max(-20, min(20, (p[1]-p[3])*0.99))
                p[2], p[3], p[0], p[1] = p[0], p[1], p[0]+vx, p[1]+vy+0.4
                
        for _ in range(6):
            for sk in [k for k in S if k[2]]:
                p1, p2 = P[sk[0]], P[sk[1]]
                dx, dy = p2[0]-p1[0], p2[1]-p1[1]
                d = math.hypot(dx, dy) or 0.1
                if d > 100 or (md[2] and math.hypot((p1[0]+p2[0])/2-mx, (p1[1]+p2[1])/2-my) < 15):
                    sk[2] = 0; continue
                f = (20-d)/d*0.5
                if not p1[4]: p1[0]-=dx*f; p1[1]-=dy*f
                if not p2[4]: p2[0]+=dx*f; p2[1]+=dy*f
                
        for p1, p2, active in [k for k in S if k[2]]:
            pygame.draw.line(s, cloth_colors[color_idx], (P[p1][0], P[p1][1]), (P[p2][0], P[p2][1]), 2)
            
        # 畫重置按鈕
        rx, ry = W - 50, 50
        pygame.draw.circle(s, (50, 50, 50), (rx, ry), 20)
        pygame.draw.circle(s, (220, 220, 220), (rx, ry), 20, 2)
        pygame.draw.arc(s, (220, 220, 220), (rx - 10, ry - 10, 20, 20), 0, math.pi * 1.5, 3)
        pygame.draw.polygon(s, (220, 220, 220), [(rx + 10, ry - 4), (rx + 4, ry + 4), (rx + 16, ry + 4)])
        
        # 畫顏色按鈕
        cx, cy = W - 110, 50
        pygame.draw.circle(s, (50, 50, 50), (cx, cy), 20)
        pygame.draw.circle(s, (220, 220, 220), (cx, cy), 20, 2)
        pygame.draw.circle(s, cloth_colors[color_idx], (cx, cy), 14)
            
        pygame.display.flip()
        await asyncio.sleep(0)  # 新增：網頁版的靈魂，強制交出控制權給瀏覽器渲染
        clock.tick(60)

# 新增：啟動非同步主程式
asyncio.run(main())
